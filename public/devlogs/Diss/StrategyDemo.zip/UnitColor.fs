#version 330

// Input vertex attributes (from vertex shader)
in vec2 fragTexCoord;
in vec4 fragColor;

// Input uniform values
uniform sampler2D texture0;
uniform vec4 colDiffuse;

uniform vec4 replaceColor;
uniform float tintAmount;

// Output fragment color
out vec4 finalColor;

void main()
{
    vec4 texel = texture(texture0, fragTexCoord);   // Get texel color
    finalColor = texel;
    if (texel == vec4(1.0)) {
        finalColor = replaceColor;
    }
    finalColor = finalColor*vec4(tintAmount, tintAmount, tintAmount, 1.0);
}